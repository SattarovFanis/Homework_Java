package com.site.homework1;

public class main {
    public static void main(String[] args) {
        System.out.println("12   24   48   136");
    }
}
